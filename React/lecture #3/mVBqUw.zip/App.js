import React from 'react';
import { SpecialComponent } from './food';
import Header from './components/header/header'
import OlxAd from './components/card/card'


export default function App() {

    let ads = [
        {
            title: "Ad 1"
        },
        {
            title: "Ad 2"
        },
        {
            title: "Ad 3"
        },
        {
            title: "Ad 4"
        }
    ];

    return <div>
        <Header />        
        <div class="row">
            {
                ads.map((ad) => {
                    return <OlxAd  data={ad} city="FSD" name="khurram" />
                })
            }
        </div>
        <h1>There is some tag</h1>
    </div>
}

