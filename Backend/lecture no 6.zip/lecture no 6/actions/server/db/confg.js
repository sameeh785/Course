let mongoose = require('mongoose');

mongoose.connect('mongodb+srv://newuser:uaPBbvwxOtvY3UfF@cluster0.ck8ev.mongodb.net/<dbname>?retryWrites=true&w=majority',{ useUnifiedTopology: true}, (err) => {

    if (!err) {
        console.log('db connected haa')
    } else {
        console.log(err);
    }

});