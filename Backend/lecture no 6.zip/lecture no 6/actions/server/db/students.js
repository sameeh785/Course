let mongoose = require('mongoose');

var studentSchema =  mongoose.Schema({
    name : String,
    password : String,
    na : {
        type : String
    }
})
studentSchema.virtual('fullName').get(function () {
    return this.name.split(' ')[0]
 })
 module.exports = mongoose.model("student", studentSchema);  //this line will create a class and then export