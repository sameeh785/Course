// CommonJS format
let express = require('express')
let bodyParser = require('body-parser');



let multer = require('multer')
let fs = require('fs');
let Student = require("./db/students");
require("./db/confg");

var storage = multer.diskStorage({
    
    destination:function(req, file, next) {
        
        let flag = users.find((user) =>{
            return user.name == req.body.name
        })
        if(flag){
            next(new Error("user alreadys"));
        }
        else{
            console.log(req.body.id)
            console.log(req.body.name)
            console.log(req.body.password)


            let path = './server/uploads/' + req.body.name;
            fs.mkdirSync(path);
            next(null, path)
        }
      
    },
    filename: function (req, file, next) {
        next(null, file.originalname)
    }
    

})

var upload = multer({ storage: storage })
let users = [];                       //ask the question from sir that can we used users variable before we can use it

let app = express();
app.use(bodyParser.urlencoded());
app.use(function(req, res, next){
    // console.log("asdas")
    next()
   
});

app.use(function(req, res, next){
    // console.log("asdas")
    next();
});

app.get('/', (req,res,next) =>{

}, (req, res) => {
    res.end("this is sgome")
    // res.json({
    //     game:"asds"
    // })
});



app.delete("/deleteUser",async(req,res)=>{
    try {
        let delUser=await Student.findByIdAndDelete(req.query.abc)
        res.json({
            succes: true
        });
    } catch (error) {
        
    }
})


app.get('/getuser',async (req,res) =>{
  try{
    let allUsers = await Student.find().select('fullName name password');
    console.log(allUsers)
    res.json(allUsers);
  }
  catch(e){
      res.send(500,{ error : e.message})
  }
})

// app.use(bodyParser.urlencoded());





app.get('/data', (req, res) => {
    // res.end("adsads");
});


app.use(bodyParser.json());


app.post("/login", async (req, res) => {
      try{
    let targetUser = await Student.findOne({
        name:req.body.name,
        password:req.body.password
    });


    res.json(targetUser);


//     let targetUser = users.find((user) => {
//         return user.name == req.body.name && user.password == req.body.password
//     });

//     res.json(targetUser);
//     console.log("hhhh");
//     console.log(users);
//     console.log(targetUser + 'user');

  }
  catch (e){
      res.send(500,{error : e.message})

  }
    // res.sendfile('./data.mp4');

    // res.end("asdas");
    // res.json({ name: "Gamica" })

});



app.get('/result/:roll', (req, res) => {

    res.end(req.params.roll + " requested for result")

})


app.post('/deleteuser', async(req, res)=>{

    await Student.remove({
        name:req.body.name
    });

})

app.put('/userupdate',async(req , res) =>{
    try{
       let updateUser = await Student.findByIdAndUpdate({_id : req.body.idNo},{name : req.body.name, password: req.body.password},{new:true})
       console.log(updateUser)
       res.json(updateUser)
    }catch(e){
     
        res.send(500,{error : e.message})
      
        
    }
})


// ,upload.single('userFile')
app.post("/signup", async (req, res) => {
    try{
        // console.log(req.body)
        // users.push(req.body)
        // res.end("hello g");
        let newStudent = new Student(req.body);
        await newStudent.save();
        res.json({
            ...newStudent.toJSON(),
            fullName:newStudent.fullName
        })
      
    }
    catch (e) {
        res.send(500, { error: e.message});

    }
   
    // res.sendfile('./data.mp4');

    // res.end("asdas");
    // res.json({ name: "Gamica" })

});

app.use(express.static('./build'));

app.listen(process.env.PORT || 8080, function () {
    console.log("Start starting");
})



// function  downloadVideo() {
//     return new Promise((success,error) =>{
//         setTimeout(() =>{

//             console.log("i am chali");
//             success(22);
//         },2000)
//     })
// }

// async function test(params) {
//     try{
//     let first = await downloadVideo();
//     let second =await SVGAnimatent(first);}
//     catch(e){
//         console.log(e)
//     }
// }