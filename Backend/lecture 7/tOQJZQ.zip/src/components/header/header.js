import React from 'react';
import './header.css';

export default function Header(){
    return <header className="header-comp">
        <h1>THis is header</h1>
    </header>
}