import React from 'react';
import './section.css';

export default function Section(){
    return <section className="section-comp">
        <h1>THis is css</h1>
    </section>
} 