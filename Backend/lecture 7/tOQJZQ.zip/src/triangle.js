
import React from 'react';
import './shape.css';

export default class Triangle extends React.Component {


    render() {

        return <div className="shape">
                <img src="triangle.png" />
        </div>

    }


}