export function makyBiryani() {

    console.log("biryani banning")

}


export function makeTikka() {

    console.log("tikka banning")


}