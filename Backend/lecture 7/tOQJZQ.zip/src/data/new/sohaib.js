
import {some} from './data2';


some();

export function makePizza(){
    alert("okay ji");
}


