

export function some(){
    alert('export somethign');
}