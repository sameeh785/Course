

import newTest from './App';

function onHeater(){

    console.log("i am heating")

}



export class Dish{


}

export function makeSoup(){

    alert("i am souping")
    onHeater();


}


function test1(){


}


export function test2(){

    alert("I am chaling test2");
    
}

let name1 = "khurram";


export function test3(){

    alert("I am chaling");
    
}