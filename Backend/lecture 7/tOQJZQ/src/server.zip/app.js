
// import {} from 'express';

let express = require('express');
let expressSession = require('express-session');

let bd = require('body-parser');
let cParser = require('cookie-parser');

let fs = require('fs');


let users = require('./authentication').users;
let passport = require('./authentication').passport;

var multer = require('multer');
// var upload = multer({ dest: './server/uploads/' })

var storage = multer.diskStorage({
    destination: function (req, file, cb) {

        let targetPath = './server/' + req.body.name;

        fs.exists(targetPath, (exist) => {

            if (exist == false) {

                fs.mkdir(targetPath, (err, data) => {

                    cb(err, targetPath)
                })

            } else {
                cb({ message: "some error occurred" }, targetPath)

            }

        });

    },
    filename: function (req, file, cb) {
        cb(null, file.originalname)
    }
})

var upload = multer({ storage: storage })

let app = express();

app.use(bd.json());
app.use(bd.urlencoded());

app.use(cParser());
app.use(expressSession({
    secret: "cat says miooon in FSD"
}));
app.use(passport.initialize());
app.use(passport.session());

passport.serializeUser((user, cb) => {

    cb(null, user.username);

})

passport.deserializeUser((userName, cb) => {


    let userFound = users.find((user) => {

        if (user.username == userName) {
            return true;
        }

    });

    cb(null, userFound);

})

app.post('/signup', function (req, res) {

    users.push(req.body);
    res.json({ success: true });

});

app.get('/logout', (req, res) => {

    req.logOut();
    res.end("SUCCESS");

});

app.get('/isloggedin', (req, res) => {

    res.end(req.isAuthenticated().toString())

});

app.post('/login', function (req, res, next) {

    passport.authenticate('local', (args, user) => {

        console.log(20);

        if (user) {




            req.logIn(user, () => {
                res.json(user);
            })
        } else {
            res.json(null);
        }

    })(req, res, next)

    // res.json(userFound || null);

});



app.use(express.static('./server/public'));

app.use((err, req, res) => {

    console.log(err);

});

app.listen(7090, () => {
    console.log("starting server");
});


// let myExpress = require('./data');

// myExpress.test();