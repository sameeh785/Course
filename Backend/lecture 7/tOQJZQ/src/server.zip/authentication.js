

let passport = require('passport');

let LocalStrategy = require('passport-local').Strategy;


let users = [];

passport.use(new LocalStrategy({    
    passwordField:"userPassword"
},(username, password, cb) => {

    let userFound = users.find((user) => {

        if (user.username == username && user.userPassword == password){
            return true;
        }

    });

    cb(null, userFound);


}));


module.exports = {
    passport, users
}